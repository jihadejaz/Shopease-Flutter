import 'package:flutter/material.dart';

class AppColours {
  static Color primaryColour = Color.fromARGB(255, 144, 194, 44);
  static Color secondaryColour = Color.fromARGB(255, 49, 48, 45);
  static Color textColours = Color.fromARGB(255, 255, 255, 255);
}
