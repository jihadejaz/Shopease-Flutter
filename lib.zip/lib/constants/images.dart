class AppImages{
  static String appLogo = 'asset/images/ecomLogo2.png';
  static String welcomePic = 'asset/images/ecomLogo.png';
}