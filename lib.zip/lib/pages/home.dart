import 'package:fluentui_system_icons/fluentui_system_icons.dart';
import 'package:flutter/material.dart';
import 'package:shopease/constants/images.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        elevation: 0,
        title: Image.asset(
          AppImages.appLogo,
          width: 50,
          height: 50,
        ),
        actions: [
          Icon(
            FluentIcons.shopping_bag_16_regular,
            color: Colors.black,
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(50),
                    borderSide: BorderSide.none,
                  ),
                  fillColor: Colors.white,
                  filled: true,
                  hintText: "Search",
                  prefixIcon: Icon(FluentIcons.search_12_regular)),
            ),

            SizedBox(
              height: 180,
              width: double.infinity,

              child: Swiper(
                itemCount: 3,
                itemBuilder: (context, index){
                  return Card(
                    shape: RoundedRectangleBorder(borderRadius: border),
                  )
                }
              ),
            )
          ],
        ),
      ),
    );
  }
}
